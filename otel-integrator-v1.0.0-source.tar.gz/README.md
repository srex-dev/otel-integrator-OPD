# OpenTelemetry Collector Distro

This distribution contains all the components from the [OpenTelemetry Collector](https://github.com/open-telemetry/opentelemetry-collector) repository and a small selection of components tied to open source projects from the [OpenTelemetry Collector Contrib](https://github.com/open-telemetry/opentelemetry-collector-contrib) repository.

## Quick Start

1. **Clone and set up Python environment:**
   ```bash
   git clone https://github.com/your-org/otel-integrator.git
   cd otel-integrator
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Run the tool in enhanced mode:**
   ```bash
   python main.py run --enhanced
   ```
   This will generate:
   - `output/generated-configs/otel-collector-config.yaml` (collector config)
   - `output/otel-config.env` (environment variables for exporters)

3. **Edit `output/otel-config.env` and fill in your exporter credentials:**
   - `ELASTIC_APM_ENDPOINT`, `ELASTIC_APM_SECRET_TOKEN`
   - `INFLUXDB_URL`, `INFLUXDB_TOKEN`, `INFLUXDB_ORG`, `INFLUXDB_BUCKET`
   - `LOKI_URL`, `LOKI_USERNAME`, `LOKI_PASSWORD`, `LOKI_ORG_ID`
   - `GRAFANA_CLOUD_OTLP_ENDPOINT`, `GRAFANA_CLOUD_API_KEY`

4. **Start the collector using the generated config and environment:**
   ```bash
   source output/otel-config.env
   ./otelcol --config output/generated-configs/otel-collector-config.yaml
   ```

5. **Check health and instrumentation:**
   ```bash
   python main.py check-backends
   python main.py check-instrumentation
   ```

## Components

The full list of components is available in the [manifest](manifest.yaml)

## Version Summary

| Component         | Version Pin/Tag         | Where Set/Documented         |
|-------------------|------------------------|------------------------------|
| OTEL Collector    | 0.96.0                 | install scripts, README      |
| Elastic APM       | 8.11.0                 | docker-compose, README       |
| InfluxDB          | 2.7.5                  | docker-compose, README       |
| Grafana           | 10.2.0                 | docker-compose, README       |

## Sample Files

- See `output/otel-config.env` for a sample environment file (Elastic is the only log backend)
- See `output/generated-configs/otel-collector-config.yaml` for a sample collector config (logs → Elastic)

## Troubleshooting

- **No logs in Elastic?**
  - Run health checks: `python main.py check-backends`
  - Check Elastic exporter endpoints and credentials in `.env`
  - Check the logs pipeline in the collector config
- **No data in backends?**
  - Run health checks: `python main.py check-backends`
  - Check exporter endpoints and credentials in `.env`
- **TLS/SSL errors?**
  - Run: `python main.py check-tls`
  - Check CA certs and endpoint URLs
- **Instrumentation missing?**
  - Run: `python main.py check-instrumentation`
  - Follow recommendations for each service
- **Pipeline failed in CI?**
  - Download artifacts and review logs in the GitHub Actions UI

## Release Notes

See `release-notes.md` for the latest changes.

## License

See `LICENSE` for license details.

## Contact & Support

For questions, issues, or support, contact:
- Your team email: ops@example.com
- GitHub Issues: https://github.com/your-org/otel-integrator/issues
